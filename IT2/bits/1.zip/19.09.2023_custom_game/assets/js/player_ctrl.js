//var player = document.getElementById("player").value;
var player = player.style.left;

/*
function init(){
	player.style.position ="relative";
	player.style.left= (innerWidth/2)+"px";
	player.style.top = (innerHeight/2)+"px";
    console.log("init successful!");
}
/*
document.addEventListener('keydown', function(event) {
    if (event.keyCode == 87) {
        console.log("w was pressed"); 
        player.style.left = parseInt(player.style.left) - 10 +"px";

    }
    else if (event.keyCode == 83) {
        console.log("s was pressed"); 
        player.style.top = parseInt(player.style.top)+10 +"px";
    }
}, true);
*/

//player.style.left = parseInt(player.style.left) - 10 +"px";

